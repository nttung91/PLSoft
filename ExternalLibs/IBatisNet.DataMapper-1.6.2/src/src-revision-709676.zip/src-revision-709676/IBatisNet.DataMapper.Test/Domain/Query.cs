namespace IBatisNet.DataMapper.Test.Domain
{
	/// <summary>
	/// Summary description for Query.
	/// </summary>
	public class Query
	{
		private object _dataObject; 

		public object DataObject
		{
			get{return _dataObject; }
			set { _dataObject = value;}
		} 

	}
}

