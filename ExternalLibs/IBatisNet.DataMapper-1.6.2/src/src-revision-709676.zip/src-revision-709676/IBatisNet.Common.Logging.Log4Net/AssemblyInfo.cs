using System.Reflection;

[assembly: AssemblyTitle("IBatisNet.Common.Logging.Log4Net")]
[assembly: AssemblyDescription("Log4Net adapter.")]


[assembly: AssemblyVersion("1.0.0")]

