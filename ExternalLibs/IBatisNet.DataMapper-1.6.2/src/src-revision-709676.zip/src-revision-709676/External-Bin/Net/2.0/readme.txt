
Log4NET 1.2.9.0
===================
log4net.dll

Castle dynamic proxy 1.1.5.0
============================
Castle.DynamicProxy.dll