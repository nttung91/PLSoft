using System;

namespace IBatisNet.DataAccess.Test.Domain
{
	/// <summary>
	/// Description r�sum�e de AccountBis.
	/// </summary>
	public class AccountBis
	{
		public int Id;
		public string FirstName;
		public string LastName;
		public string EmailAddress;
	}
}
