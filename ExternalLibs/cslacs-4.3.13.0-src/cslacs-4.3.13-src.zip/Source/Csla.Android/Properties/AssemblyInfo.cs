//-----------------------------------------------------------------------
// <copyright file="AssemblyInfo.cs" company="Marimer LLC">
//     Copyright (c) Marimer LLC. All rights reserved.
//     Website: http://www.lhotka.net/cslanet/
// </copyright>
// <summary>no summary</summary>
//-----------------------------------------------------------------------
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("CSLA .NET for Android")]
[assembly: AssemblyDescription("CSLA .NET for Android")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Marimer LLC")]
[assembly: AssemblyProduct("CSLA .NET")]
[assembly: AssemblyCopyright("Copyright � 2010-12 Marimer LLC")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("4.3.13.0")]
[assembly: AssemblyFileVersion("4.3.13.0")]
[assembly: AssemblyKeyFileAttribute("CslaKey.snk")]

