﻿//-----------------------------------------------------------------------
// <copyright file="InheritedProvider.cs" company="Marimer LLC">
//     Copyright (c) Marimer LLC. All rights reserved.
//     Website: http://www.lhotka.net/cslanet/
// </copyright>
// <summary>no summary</summary>
//-----------------------------------------------------------------------
#if !WINDOWS_PHONE
using System;

namespace cslalighttest.CslaDataProvider
{
  public class InheritedProvider : Csla.Xaml.CslaDataProvider
  {

  }
}
#endif
