﻿namespace NHibernate.DomainModel.Northwind.Entities
{
    public class AnotherEntity
    {
        public virtual int Id { get; set; }
        public virtual string Output { get; set; }
		public virtual string Input { get; set; }
    }
}