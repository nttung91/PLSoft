using System;

namespace NHibernate.DomainModel
{
	public interface INamed
	{
		string Name { get; }
	}
}