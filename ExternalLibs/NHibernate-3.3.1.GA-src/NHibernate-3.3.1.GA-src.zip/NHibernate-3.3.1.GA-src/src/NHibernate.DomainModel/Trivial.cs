using System;

namespace NHibernate.DomainModel
{
	[Serializable]
	public class Trivial : Foo
	{
	}
}