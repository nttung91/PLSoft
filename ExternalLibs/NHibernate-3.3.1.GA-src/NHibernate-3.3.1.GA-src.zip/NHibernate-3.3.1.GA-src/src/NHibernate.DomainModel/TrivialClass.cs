using System;

namespace NHibernate.DomainModel
{
	public class TrivialClass : Top
	{
	}
}