namespace NHibernate.Test.BulkManipulation
{
	public class SimpleClass
	{
		public virtual string Description { get; set; }
	}
}