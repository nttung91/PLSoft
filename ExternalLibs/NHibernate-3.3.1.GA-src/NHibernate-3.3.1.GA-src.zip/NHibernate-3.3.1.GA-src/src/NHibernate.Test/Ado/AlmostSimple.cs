namespace NHibernate.Test.Ado
{
	public class AlmostSimple
	{
		public virtual int Id { get; set; }
		public virtual string Name { get; set; }
		public virtual double Weight { get; set; }
	}
}